﻿using UnityEngine;
using System.Collections;
using System.Net;
using System;
using System.IO;
using System.Text;
using System.IO.Compression;
//using TheNextFlow.UnityPlugins;


public class TestPOST : MonoBehaviour {

	static HttpWebRequest hwrequest;


	// Use this for initialization
	void Start () {

		System.Net.ServicePointManager.ServerCertificateValidationCallback = delegate { return true; }; 
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public static string WRequestPOST(string URL, string method, byte[] postData)
	{
		string responseData = "";
		try
		{
			System.Net.CookieContainer cookieJar = new System.Net.CookieContainer();
			hwrequest =	(System.Net.HttpWebRequest) System.Net.WebRequest.Create(URL);
			hwrequest.CookieContainer = cookieJar;
			hwrequest.Accept = "*/*";
			hwrequest.ContentType = "application/x-www-form-urlencoded";
			hwrequest.AllowAutoRedirect = true;
			hwrequest.UserAgent = "MOSKIT_Plugin";
			hwrequest.Timeout= 60000;
			hwrequest.Method = method;
			if (hwrequest.Method == "POST")  // Send GameObjectData data
			{
				// Use UTF8Encoding instead of ASCIIEncoding for XML requests:
				//System.Text.ASCIIEncoding encoding = new System.Text.ASCIIEncoding();
				byte[] postByteArray = postData;//reusableBuffer;
				hwrequest.ContentLength = postByteArray.Length;
				System.IO.Stream postStream = hwrequest.GetRequestStream();
				postStream.BeginWrite(postByteArray, 0, postByteArray.Length, new AsyncCallback(AsyncWriteEvent), hwrequest);
			}
		}
		catch (Exception e)
		{
			responseData = "An error occurred: " + e.Message;
		}
		return responseData;
	}

	static void AsyncWriteEvent(IAsyncResult rslt)
	{
		try{

			HttpWebResponse hwresponse = (HttpWebResponse) hwrequest.GetResponse();
			if (hwresponse.StatusCode == HttpStatusCode.OK)
			{
				Stream responseStream = hwresponse.GetResponseStream();
				StreamReader myStreamReader = new StreamReader(responseStream);
				string responseData = myStreamReader.ReadToEnd();

				Debug.Log ("Length : " + responseData.Length + "  /  " + responseData);
//				AndroidNativePopups.OpenToast("Oppa",AndroidNativePopups.ToastDuration.Long);
			}
			hwresponse.Close();
		}
		catch(WebException err)
		{
			using (var stream = err.Response.GetResponseStream())
			{
				using (var reader = new StreamReader(stream))
				{
					Debug.Log ("Response Error : " + reader.ReadToEnd());
					//Console.WriteLine(reader.ReadToEnd());
				}
			}


		}
	}
}
