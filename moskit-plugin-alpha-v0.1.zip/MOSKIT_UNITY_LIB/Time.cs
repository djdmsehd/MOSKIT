﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace MSAnalyzer.MOSKIT_UNITY_LIB
{
	[Serializable]
	[XmlRoot("Time")]
	public class Time
	{
		[XmlAttribute("deltaTime")]
		public float deltaTime { get; set; }

		[XmlAttribute("frameCount")]
		public int frameCount { get; set; }

		[XmlAttribute("time")]
		public float time { get; set; }


		public Time()
		{
			frameCount = 0;
			deltaTime = 0.0f;
			time = 0.0f;
		}
	}
}
