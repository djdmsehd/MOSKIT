﻿using System.Collections;
using System.Xml.Serialization;
using System;

namespace MSAnalyzer.MOSKIT_UNITY_LIB
{
	[Serializable]
	[XmlRoot("MainCamera")]
	public class MainCamera
	{

		[XmlAttribute("name")]
		public string name;

		[XmlAttribute("active")]
		public bool active;

		//[XmlAttribute("isStatic")]	
		//public bool isStatic;

		[XmlAttribute("layer")]
		public int layer;

		[XmlAttribute("instanceID")]
		public int instanceID;

		[XmlAttribute("tag")]
		public string tag;


		public Transform transform;


		public MainCamera()
		{
			transform = new Transform();
		}
	}
}