﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MSAnalyzer.MOSKIT_UNITY_LIB
{
    class ResultAnalysis
    {
        List<GameObject> list_obj;

        public ResultAnalysis()
        {
            list_obj = new List<GameObject>();
            list_obj.Clear();
        }
    }
}
