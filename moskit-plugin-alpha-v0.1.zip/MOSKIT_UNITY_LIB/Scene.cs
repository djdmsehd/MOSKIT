﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MSAnalyzer.MOSKIT_UNITY_LIB
{
	[Serializable]
    public class Scene
    {
        public Time time { get; set; }
		public MainCamera Camera{ get; set; }
		public List<GameObject> list_gameObject{ get; set; }

        public Scene()
        {
            time = new Time();
			Camera = new MainCamera ();
			list_gameObject = new List<GameObject>();
        }
    }
}
