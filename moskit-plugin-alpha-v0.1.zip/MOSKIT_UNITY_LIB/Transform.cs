﻿using System.Collections;
using System;

namespace MSAnalyzer.MOSKIT_UNITY_LIB
{
	[Serializable]
	public class Transform {
		
		public Vector3 eulerAngles;
		public Vector3 position;
		public Vector3 angularVelocity;

		public int parent;

		public Transform()
		{
			eulerAngles = new Vector3();
			position = new Vector3();

			//angularvelocity
			angularVelocity = new Vector3();

			parent = -1;
		}
	}
}

