﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Xml.Serialization;
using System.IO;
using System;
using System.Text;
using System.Threading;

public class ExportXMLPlugin_MTP : MonoBehaviour {

	public static string str_GuidTitle = "167AB079-B698-4DFA-8000-47D6DD318E67";
	public static Guid nUIDGameObjecData;

	int chunk_cnt = 0;
	int gameObjectCounter = 0;

	private List<MSAnalyzer.MOSKIT_UNITY_LIB.Scene> list_scene = null;
	private System.Object listscenelock = new System.Object ();

	private List<byte[]> uploadQueue = null;
	private System.Object uploadlock = new System.Object ();

	// Use this for initialization
	void Start () {
		if(list_scene == null)
			list_scene = new List<MSAnalyzer.MOSKIT_UNITY_LIB.Scene> ();

		if (uploadQueue == null)
			uploadQueue = new List<byte[]> ();

		list_scene.Clear ();
		chunk_cnt = 0;
		gameObjectCounter = 0;

		RequestNewGuidForGOD.WRequestPOST(@"http://1.233.212.138/WcfService1/InsertGameObjectData.svc/GenerateGameObjectDataUID", "POST", str_GuidTitle);
	}
	
	void Update()
	{
		int gameObjNodeCount = AddNode ();

		if (nUIDGameObjecData == null || nUIDGameObjecData == Guid.Empty) 
		{
			Debug.Log ("gameobjectuid is empty, skip : time - " + Time.time);
			return;
		}
		
		if (gameObjectCounter > 3000) 
		{
			ThreadPool.QueueUserWorkItem (BGSerializerAndCompressor, chunk_cnt++);
			gameObjectCounter = 0;
		}
		gameObjectCounter += gameObjNodeCount;


		lock (uploadlock) 
		{
			if (uploadQueue.Count > 0) 
			{
				foreach (byte[] compressed in uploadQueue) 
				{
					TestPOST.WRequestPOST (@"http://1.233.212.138/WcfService1/InsertGameObjectData.svc/DoWork", "POST", compressed);
				}
				uploadQueue.Clear ();
			}
		}
	}

	void OnDestroy()
	{
		 
	}
		
	private void BGSerializerAndCompressor(object param)
	{
		int chunkCnt = (int)param;

		try
		{
			/////////Serialize Data
			XmlSerializer serializer = new XmlSerializer (typeof(List<MSAnalyzer.MOSKIT_UNITY_LIB.Scene>));
			string strXMLString = "";

			List<MSAnalyzer.MOSKIT_UNITY_LIB.Scene> list_scene_copy;
			lock (listscenelock) 
			{
				list_scene_copy = new List<MSAnalyzer.MOSKIT_UNITY_LIB.Scene>(list_scene);
			}

			using (TextWriter txtWriter = new StringWriter ()) 
			{
				serializer.Serialize (txtWriter, list_scene_copy);
				strXMLString += txtWriter.ToString ();
			}

			lock (listscenelock) 
			{
				list_scene.Clear ();
			}
			list_scene_copy.Clear();

			Debug.Log(strXMLString.Length);

			byte[] text1 = Encoding.ASCII.GetBytes(strXMLString + ",GuidTitle=" + str_GuidTitle + ",ChunkCount=" + chunkCnt +
				",GuidGameObjectData=" + nUIDGameObjecData.ToString());
			
			CLZF2 comp_ob = new CLZF2 ();
			byte[] compressed = comp_ob.Compress (text1);	

			lock (uploadlock) 
			{
				uploadQueue.Add (compressed);
			}
		}
		catch(Exception ee) 
		{
			Debug.Log ("Error on MultiThreaded BGSerializerAndCompressor() : " + ee.Message + ", chunkcou = " + chunkCnt);
		}
	}

	private int AddNode()
	{
		MSAnalyzer.MOSKIT_UNITY_LIB.Scene new_scene = new MSAnalyzer.MOSKIT_UNITY_LIB.Scene ();
		new_scene.time = MakeTimeStructure ();
		new_scene.list_gameObject = MakeGameObject ();	

		lock (listscenelock) 
		{
			list_scene.Add (new_scene);
		}

		return new_scene.list_gameObject.Count;
	}

	private MSAnalyzer.MOSKIT_UNITY_LIB.Time MakeTimeStructure()
	{
		MSAnalyzer.MOSKIT_UNITY_LIB.Time time = new MSAnalyzer.MOSKIT_UNITY_LIB.Time ();
		time.deltaTime  = Time.deltaTime ;
		time.frameCount  = Time.frameCount ;
		time.time   = Time.time  ;

		return time;
	}

	private List<MSAnalyzer.MOSKIT_UNITY_LIB.GameObject> MakeGameObject()
	{
		List<MSAnalyzer.MOSKIT_UNITY_LIB.GameObject> list_gameobj = new List<MSAnalyzer.MOSKIT_UNITY_LIB.GameObject> ();
		GameObject[] allObjList = GameObject.FindObjectsOfType<GameObject> ();

		//Debug.Log ("size of allObjList = " + allObjList.Length);
		//return list_gameobj;

		for(int i=0; i<allObjList.Length; i++)
		{
			MSAnalyzer.MOSKIT_UNITY_LIB.GameObject insert_obj = new MSAnalyzer.MOSKIT_UNITY_LIB.GameObject ();
			insert_obj.name = allObjList[i].name;
			insert_obj.isStatic = allObjList[i].isStatic;
			insert_obj.layer = allObjList[i].layer;
			insert_obj.tag = allObjList[i].tag;
			insert_obj.transform = MakeTransform(allObjList[i].transform);
			list_gameobj.Add(insert_obj);
		}

		return list_gameobj;
	}

	private MSAnalyzer.MOSKIT_UNITY_LIB.Transform MakeTransform(Transform transf_)
	{
		MSAnalyzer.MOSKIT_UNITY_LIB.Transform transf = new MSAnalyzer.MOSKIT_UNITY_LIB.Transform ();

		transf.eulerAngles = new MSAnalyzer.MOSKIT_UNITY_LIB.Vector3(transf_.eulerAngles);
		transf.position = new MSAnalyzer.MOSKIT_UNITY_LIB.Vector3(transf_.position);

		if (transf_.parent == null)
			transf.parent = 0;
		else
			transf.parent = transf_.parent.gameObject.GetInstanceID ();

		return transf;
	}

}
