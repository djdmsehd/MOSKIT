﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WcfService1.Utils
{
	[Serializable]
	public class stPacketData
	{
		public bool blsDebug;
		public string guidTitle;
		public int chunkCou;
		public string guidGameObjectData;
		public byte[] gameobjData;
	}
}