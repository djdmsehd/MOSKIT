﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Xml.Serialization;
using System.IO;
using System;
using System.Text;
using System.Threading;
using System.Runtime.Serialization.Formatters.Binary;
using WcfService1.Utils;


public class ExportXMLPlugin_MTW : MonoBehaviour {

	public static string str_GuidTitle = "Title UID";
	public static string str_Version = "Game Version Name";
	public static Guid nUIDGameObjecData;

	public Camera MainCamera;

    Quaternion lastRotation;
	float magnitude;
	Vector3 axis;

	#if UNITY_ANDROID
	// Start frameCountGap solution
	int frameCountGap;
	float timeGap;
	// End frameCountGap solution
	#endif

	public List<MSAnalyzer.MOSKIT_UNITY_LIB.Scene> list_scene = null;

	private static System.Object threadexitlock = new System.Object ();

	class ThreadParam
	{
		public bool bIsThreadExit = false;
		public int nThreadNum = 0;
		public int nChunkCou = -1;
	}

	ThreadManager threadMng = new ThreadManager();

	class ThreadManager
	{
		const int SIZE_THREAD = 3;
		public bool[] isThreadAvail = { true, true, true };
		public int nIsAvailableThread = -1;
		public int nChunkCou = 0;

		public List<MSAnalyzer.MOSKIT_UNITY_LIB.Scene> sceneBuff1 = new List<MSAnalyzer.MOSKIT_UNITY_LIB.Scene>();
		public List<MSAnalyzer.MOSKIT_UNITY_LIB.Scene> sceneBuff2 = new List<MSAnalyzer.MOSKIT_UNITY_LIB.Scene>();
		public List<MSAnalyzer.MOSKIT_UNITY_LIB.Scene> sceneBuff3 = new List<MSAnalyzer.MOSKIT_UNITY_LIB.Scene>();
		public List<MSAnalyzer.MOSKIT_UNITY_LIB.Scene>[] sceneBuffSet = new List<MSAnalyzer.MOSKIT_UNITY_LIB.Scene>[3];

		private Thread subThread1;
		private	Thread subThread2;
		private Thread subThread3;

		private ThreadParam[] threadParams = new ThreadParam[3];

		public void PresetVar()
		{
			sceneBuffSet [0] = sceneBuff1;
			sceneBuffSet [1] = sceneBuff2;
			sceneBuffSet [2] = sceneBuff3;
		}

		public void PresetThread (ThreadParam param1, ThreadParam param2, ThreadParam param3)
		{
			threadParams [0] = param1;
			threadParams [1] = param2;
			threadParams [2] = param3;

			subThread1 = new Thread (new ParameterizedThreadStart (BGSerializerAndCompressor));
			subThread2 = new Thread (new ParameterizedThreadStart (BGSerializerAndCompressor));
			subThread3 = new Thread (new ParameterizedThreadStart (BGSerializerAndCompressor));

			param1.nThreadNum = 0;
			subThread1.Start (param1);

			param2.nThreadNum = 1;
			subThread2.Start (param2);

			param3.nThreadNum = 2;
			subThread3.Start (param3);

			subThread1.Priority = System.Threading.ThreadPriority.Lowest;
			subThread2.Priority = System.Threading.ThreadPriority.Lowest;
			subThread3.Priority = System.Threading.ThreadPriority.Lowest;
		}

		public void Destroy()
		{
			subThread1.Join ();
			subThread2.Join ();
			subThread3.Join ();
		}

		public void AddGameObjectDataMng(List<MSAnalyzer.MOSKIT_UNITY_LIB.Scene> list_scene, int gameObjNodeCount)
		{
			nIsAvailableThread = -1;

			for(int i=0; i<SIZE_THREAD; i++)
			{
				if(gameObjNodeCount > 3000 && isThreadAvail[i])
				{
					nIsAvailableThread = i;
					break;
				}
			}

			if (nIsAvailableThread < 0)
				return;

			threadParams[nIsAvailableThread].nChunkCou = nChunkCou++;
			isThreadAvail[nIsAvailableThread] = false;
			sceneBuffSet[nIsAvailableThread] = new List<MSAnalyzer.MOSKIT_UNITY_LIB.Scene>(list_scene);
			list_scene.Clear();
		}

		private void BGSerializerAndCompressor(object param)
		{
			ThreadParam threadParam = (ThreadParam)param;
			bool bIsThreadExit = false;

			while (!bIsThreadExit) 
			{
				lock (threadexitlock) 
				{
					bIsThreadExit = threadParam.bIsThreadExit;
				}

				if(isThreadAvail[threadParam.nThreadNum]) continue;
				TextWriter txtWriter = new StringWriter ();
				XmlSerializer serializer = new XmlSerializer (typeof(List<MSAnalyzer.MOSKIT_UNITY_LIB.Scene>));

				List<MSAnalyzer.MOSKIT_UNITY_LIB.Scene> list_scene_copy = sceneBuffSet[threadParam.nThreadNum];

				using (txtWriter) 
				{
					serializer.Serialize (txtWriter, list_scene_copy);
				}	

				byte[] data = Encoding.UTF8.GetBytes(txtWriter.ToString ());
				CLZF2 comp_ob = new CLZF2 ();
				byte[] compressed = comp_ob.Compress (data);

				stPacketData p = new stPacketData();
				p.blsDebug = true;
				p.chunkCou = threadParam.nChunkCou;
				p.guidGameObjectData = nUIDGameObjecData.ToString();
				p.guidTitle = str_GuidTitle;
				p.gameobjData = compressed;

				MemoryStream m = new MemoryStream();
				BinaryFormatter formatter = new BinaryFormatter();
				formatter.AssemblyFormat = System.Runtime.Serialization.Formatters.FormatterAssemblyStyle.Simple;
				formatter.Serialize(m,p);

				isThreadAvail[threadParam.nThreadNum] = true;
				Debug.Log (m.ToArray ().Length);
				TestPOST.WRequestPOST (@"http://1.233.212.138/WcfService1/InsertGameObjectData.svc/AddGameObjectData", "POST", m.ToArray());
			}
		}
	}

	private ThreadParam threadParam1 = new ThreadParam();
	private ThreadParam threadParam2 = new ThreadParam();
	private ThreadParam threadParam3 = new ThreadParam();

	public int accumCount = 0;

	void Start ()
	{
		threadMng.PresetVar ();
		threadMng.PresetThread (threadParam1, threadParam2, threadParam3);
		accumCount = 0;

		RequestNewGuidForGOD.WRequestPOST(@"http://1.233.212.138/WcfService1/InsertGameObjectData.svc/GenerateGameObjectDataUID", "POST", str_GuidTitle + "," + str_Version);

		#if UNITY_ANDROID
		frameCountGap = Time.frameCount - 1;
		timeGap = Time.time;
		#endif

		lastRotation = MainCamera.transform.rotation;
	}

	void Update()
	{
		Quaternion deltaRotation = MainCamera.transform.rotation * Quaternion.Inverse(lastRotation);
		deltaRotation.ToAngleAxis (out magnitude, out axis);
		lastRotation = MainCamera.transform.rotation;

		int gameObjNodeCount = AddNode ();

		if (nUIDGameObjecData == null || nUIDGameObjecData == Guid.Empty) 
		{
			Debug.Log ("gameobjectuid is empty, skip : time - " + Time.time);
			return;
		}

		accumCount += gameObjNodeCount;

		threadMng.AddGameObjectDataMng(list_scene, accumCount);
		if (accumCount > 3000)
			accumCount = 0;
	}

	private int AddNode()
	{
		MSAnalyzer.MOSKIT_UNITY_LIB.Scene new_scene = new MSAnalyzer.MOSKIT_UNITY_LIB.Scene ();
		new_scene.time = MakeTimeStructure ();
		new_scene.Camera = MakeCamera ();
		new_scene.list_gameObject = MakeGameObject ();
		list_scene.Add(new_scene);
		return new_scene.list_gameObject.Count;
	}

	void OnDestroy()
	{
		lock (threadexitlock) 
		{
			threadParam1.bIsThreadExit = true;
			threadParam2.bIsThreadExit = true;
			threadParam3.bIsThreadExit = true;
		}
		threadMng.Destroy ();
	}

	private MSAnalyzer.MOSKIT_UNITY_LIB.Time MakeTimeStructure()
	{
		MSAnalyzer.MOSKIT_UNITY_LIB.Time time = new MSAnalyzer.MOSKIT_UNITY_LIB.Time ();
		time.deltaTime  = Time.deltaTime ;
		time.frameCount  = Time.frameCount ;
		time.time   = Time.time  ;

		#if UNITY_ANDROID
		time.frameCount -= frameCountGap;
		time.time -= timeGap;
		#endif

		return time;
	}


	private MSAnalyzer.MOSKIT_UNITY_LIB.MainCamera MakeCamera()
	{
		MSAnalyzer.MOSKIT_UNITY_LIB.MainCamera insert_cam = new MSAnalyzer.MOSKIT_UNITY_LIB.MainCamera ();
		insert_cam.name = MainCamera.name;
		insert_cam.tag = MainCamera.tag;
		insert_cam.transform = MakeTransform (MainCamera.transform);

		return insert_cam;
	}

	public Vector3 AngularVelocity
	{
		get {
			return (axis * magnitude) / Time.deltaTime;
		}
	}

	private List<MSAnalyzer.MOSKIT_UNITY_LIB.GameObject> MakeGameObject()
	{
		List<MSAnalyzer.MOSKIT_UNITY_LIB.GameObject> list_gameobj = new List<MSAnalyzer.MOSKIT_UNITY_LIB.GameObject> ();
		GameObject[] allObjList = GameObject.FindObjectsOfType<GameObject> ();

		List<GameObject> list_parentobj = new List<GameObject> ();

		for (int i = 0; i < allObjList.Length; i++) 
		{
			Renderer rendrr = allObjList[i].GetComponent<Renderer>();

			if (rendrr == null)
				continue;
			else if (rendrr.isVisible) {
				MSAnalyzer.MOSKIT_UNITY_LIB.GameObject insert_obj = new MSAnalyzer.MOSKIT_UNITY_LIB.GameObject ();
				insert_obj.name = allObjList[i].name;
				insert_obj.isStatic = allObjList[i].isStatic;
				insert_obj.layer = allObjList[i].layer;
				insert_obj.tag = allObjList[i].tag;
				insert_obj.instanceID = allObjList [i].GetInstanceID ();
				insert_obj.transform = MakeTransform(allObjList[i].transform);
				list_gameobj.Add(insert_obj);
			}
		}
		return list_gameobj;
	}

	private MSAnalyzer.MOSKIT_UNITY_LIB.Transform MakeTransform(Transform transf_)
	{
		MSAnalyzer.MOSKIT_UNITY_LIB.Transform transf = new MSAnalyzer.MOSKIT_UNITY_LIB.Transform ();

		transf.eulerAngles = new MSAnalyzer.MOSKIT_UNITY_LIB.Vector3(transf_.eulerAngles);
		transf.position = new MSAnalyzer.MOSKIT_UNITY_LIB.Vector3(transf_.position);
		transf.angularVelocity = new MSAnalyzer.MOSKIT_UNITY_LIB.Vector3 (AngularVelocity);

		if (transf_.parent == null)
			transf.parent = 0;
		else
			transf.parent = transf_.parent.gameObject.GetInstanceID ();
		
		return transf;
	}
}      