﻿using UnityEngine;
using System.Collections;
using System.Net;
using System;
using System.Text;
using System.IO;

public class RequestNewGuidForGOD : MonoBehaviour {

	static HttpWebRequest hwrequest;

	
	public static string WRequestPOST(string URL, string method, string guid_title)
	{
		string responseData = "";
		try
		{
			System.Net.CookieContainer cookieJar = new System.Net.CookieContainer();
			hwrequest =	(System.Net.HttpWebRequest) System.Net.WebRequest.Create(URL);
			hwrequest.CookieContainer = cookieJar;
			hwrequest.Accept = "*/*";
			hwrequest.ContentType = "application/x-www-form-urlencoded";
			hwrequest.AllowAutoRedirect = true;
			hwrequest.UserAgent = "MOSKIT_Plugin";
			hwrequest.Timeout= 60000;
			hwrequest.Method = method;
			if (hwrequest.Method == "POST")  // Send GameObjectData data
			{
				// Use UTF8Encoding instead of ASCIIEncoding for XML requests:
				byte[] postByteArray = Encoding.UTF8.GetBytes(guid_title);
				hwrequest.ContentLength = postByteArray.Length;
				System.IO.Stream postStream = hwrequest.GetRequestStream();
				postStream.BeginWrite(postByteArray, 0, postByteArray.Length, new AsyncCallback(AsyncWriteEvent), hwrequest);
			}
		}
		catch (Exception e)
		{
			responseData = "An error occurred: " + e.Message;
		}
		return responseData;
	}
	
	static void AsyncWriteEvent(IAsyncResult rslt)
	{
		try{

			HttpWebResponse hwresponse = (HttpWebResponse) hwrequest.GetResponse();
			if (hwresponse.StatusCode == HttpStatusCode.OK)
			{
				Stream responseStream = hwresponse.GetResponseStream();
				StreamReader myStreamReader = new StreamReader(responseStream);
				string responseData = myStreamReader.ReadToEnd();
				responseData = responseData.Replace("\"", "");
				ExportXMLPlugin_MTW.nUIDGameObjecData = new Guid(responseData);
				
				Debug.Log ("Length : " + responseData.Length + "  /  " + responseData);
   			}
			hwresponse.Close();
		}
		catch(WebException err)
		{
			using (var stream = err.Response.GetResponseStream())
			{
				using (var reader = new StreamReader(stream))
				{
					Debug.Log ("Response Error : " + reader.ReadToEnd());
					//Console.WriteLine(reader.ReadToEnd());
				}
			}
			
			
		}
	}

}
